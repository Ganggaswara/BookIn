/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aryadharm
 */
package project;

import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Tables {
    public static void main(String[] args) {
        Connection con = null;
        Statement st = null;

        try {
            con = ConnectionProvider.getConnection();
            st = con.createStatement();
            //st.executeUpdate("create table users(fullname varchar(20),email varchar(20),username varchar(20),password varchar(50),status varchar(20))");
            //st.executeUpdate("create table rooms(roomNumber varchar(100),type varchar (20),bed varchar(200),price int,status varchar (20))");
            //st.executeUpdate("create table customerCheckIn(customerName varchar(200),mobileNumber varchar(20),email varchar(20),nationality varchar(20),NIK varchar(200),address varchar (30),checkInDate varchar (50),gender varchar(10),bed varchar(200),roomNumber varchar(20),type varchar(20),price varchar(50))");
            //st.executeUpdate("create table customerCheckOut(customerName varchar(100),checkInDate varchar (20),checkOutDate varchar(200),mobileNumber int,pricePerDay varchar (200),numberDays varchar (200),address varchar (200),email varchar (20))");
            st.executeUpdate("create table customerBooking(customerName varchar(200),mobileNumber varchar(20),email varchar(20),nationality varchar(20),NIK varchar(200),address varchar (30),checkInDate varchar (50),gender varchar(10),bed varchar(200),type varchar(20))");
           JOptionPane.showMessageDialog(null, "Tabel Sudah Berhasil Dibuat");

            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            
        } finally {
            try {
                st.close();
                con.close();
            } catch (Exception e) {
                
            }
        }
    }
}
